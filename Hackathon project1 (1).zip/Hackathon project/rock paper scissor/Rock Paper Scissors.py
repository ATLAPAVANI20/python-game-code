
#random module give the access to generate random numbers
import random
#imported sqlite3 for database purpose
import sqlite3
#connection it represents database
conn = sqlite3.connect(r'C:\Users\91901\PycharmProjects\gameProject\game1\game.db')
# greeting message
greet = input("Welcome to the game!!!")
#to print the about the game
print('ABOUT GAME:\n' '___________\n\n' 
          ' 1. Rules of this game \n'
           'a.Rock smashes scissors\n'
           'b.Paper covers rock\n'
           'c.Scissors cut paper\n\n')
name = input("Enter your name:")
print("Fun starts", name)
#it will give  result for firstchoice
result = ['win','tiebreak','lose']
a = result[0]
b = result[1]
c = result[2]
#below the  result for secondchoice in var5
result3 = ['win','tiebreak','lose']
d = result3[0]
e = result3[1]
f = result3[2]

# With the while loop we can execute a set of statements as long as a condition is true
while True:
    print('Enter your choice: ')
    print(' 1.rock ','2.paper ',' 3.scissors ')
    user_choice = input()
    print("my choice is",user_choice)
    choices = ['rock','paper','scissors']
    #here computer randomly select in the list
    computer_choice = random.choice(choices)
    print("computer choice is",computer_choice)
    #using an if--elif--else block it compare the player choices and determine the winner
    if user_choice == 'rock' :
        if computer_choice == 'rock' :
            print('It is a ',b)
        elif computer_choice == 'paper' :
            print('you', c ,'sorry:(')
        elif computer_choice == 'scissors':
            print('you', a,'congrats:)')
    # using an if--elif--else block it compare the player choices and determine the winner
    if user_choice == 'paper' :
        if computer_choice == 'paper' :
            print('It is a ',b)
        elif computer_choice == 'scissors':
            print('you', c ,'sorry:(')
        elif computer_choice == 'rock' :
            print('you',a,'congrats:)')
    # using an if--elif--else block it compare the player choices and determine the winner
    if user_choice == 'scissors' :
        if computer_choice == 'scissors':
            print('It is a ',b)
        elif computer_choice == 'rock' :
            print('you', c ,'sorry:(')
        elif computer_choice == 'paper':
            print('you', a,'congrats:)')
#HERE WE GIVE THE INPUT FOR THE SECOND CHANCE TO PLAY
    new_game = input("you have one more try,press 'y' to continue::")
    if new_game == 'y':
        #here user enter the choice
        print('Enter your choice: ')
        print(' 1.rock ', '2.paper ', ' 3.scissors ')
        user_choice1= input()
        print("my choice is", user_choice1)
        choices = ['rock', 'paper', 'scissors']
        computer_choice1 = random.choice(choices)
        print("computer choice is", computer_choice1)
        #using an if--elif--else block it compare the player choices and determine the winner
        if user_choice1 == 'rock' :
            if computer_choice1 == 'rock' :
                print('It is a ', e)
            elif computer_choice1 == 'paper' :
                print('you', f, 'sorry:(')
            elif computer_choice1 == 'scissors':
                print('you', d, 'congrats:)')
        # using an if--elif--else block it compare the player choices and determine the winner
        if user_choice1 == 'paper':
            if computer_choice1 == 'paper' :
                print('It is a ', e)
            elif computer_choice1 == 'scissors':
                print('you', f, 'sorry:(')
            elif computer_choice1 == 'rock' :
                print('you win,congrats:)')
        # using an if--elif--else block it compare the player choices and determine the winner
        if user_choice1 == 'scissors' :
            if computer_choice1 == 'scissors':
                print('It is a ', e)
            elif computer_choice1 == 'rock' :
                print('you', f, 'sorry:(')
            elif computer_choice1 == 'paper' :
                print('you', d, 'congrats:)')

# With the break statement we can stop the loop even
        break
    else:
        print("thanks for playing!!")
        break
#player name is initialised to variable
var1 = "'" + name + "'"
# user_choice is intialised to variable
var2 = "'" + user_choice + "'"
# using an if--elif--else block it compare the player choices and determine the winner
if user_choice == "paper" and computer_choice == "rock" or user_choice == "scissors" and computer_choice == "paper" or user_choice == "rock" and computer_choice == "scissors":
    var3 = "'" + a + "'"
elif user_choice == "paper" and computer_choice == "scissors" or user_choice == "scissors" and computer_choice == "rock" or user_choice == "rock" and computer_choice == "paper":
    var3 = "'" + c + "'"
else:
    var3 = "'" + b + "'"

var4 = "'" + user_choice1 + "'"
# using an if--elif--else block it compare the player choices and determine the winner
if user_choice1 == "paper" and computer_choice1 == "rock" or user_choice1 == "scissors" and computer_choice1 == "paper" or user_choice1 == "rock" and computer_choice1 == "scissors":
    var5 = "'" + d + "'"
elif user_choice1 == "paper" and computer_choice1 == "scissors" or user_choice1 == "scissors" and computer_choice1 == "rock" or user_choice1 == "rock" and computer_choice1 == "paper":

    var5 = "'" + f + "'"
else:
    var5 = "'" + e + "'"

query = "insert into rps (name,firstchoice,result1,secondchoice,result2) values(" + var1 + "," + var2 + ","+ var3 + "," + var4 + "," + var5 + ")"
#it will execute the query
conn.execute(query)
# it save the changes
conn.commit()
#it close the connection
conn.close()
print("data saved..")
















